---
name: better-decisions
description: Decision-support pipeline for non-trivial choices. Triggers on "should I", "help me decide", "what would you recommend", "use better-decisions", or any request for a recommendation involving meaningful stakes — irreversibility, real cost, time pressure, downstream impact, or emotional weight. Runs precedent research (when external analogues exist), reviews available context, applies WRAP (Heath brothers), OOC/EMR (Tony Robbins), and a Klein-style pre-mortem on the committed plan in full, then synthesizes one recommendation, an immediate next action, and a tripwire. Use this skill whenever the user is weighing a real choice, even if they don't name a framework or invoke the skill explicitly. Do NOT use for trivial preferences, factual lookups, emotional venting, or cases where the user has already decided and just wants execution help.
---

# better-decisions

## When to use

Fire when the user is weighing a real decision and at least one of these is true:
- The choice is hard to reverse (job change, hire, big purchase, public commitment).
- It involves meaningful cost — money, time, reputation, or relationships.
- It has downstream effects beyond the immediate moment.
- The user explicitly asks for a recommendation, says "should I", or invokes the skill by name.

## When NOT to use

- Trivial preferences ("coffee or tea") — answer normally.
- Pure factual questions ("how does OAuth work").
- Emotional venting where the user wants to be heard, not advised.
- Cases where the user has already decided and just wants execution help.
- **Phrasing, timing, or micro-decisions** reversible within a day ("write today or tomorrow", "use semicolons or not", "tweak this subject line") — give a 100-word trade-off summary, not the full pipeline.

The Pre-flight stakes-triage step handles borderline cases. Don't reflexively ask the user to choose between full pipeline and quick take; pick based on stakes and downshift to the trade-off summary when the answer is obviously small.

## Pre-flight — before running the pipeline

Two checks before Phase 1.

**Stakes triage.** Is the question above the threshold? If it is phrasing, timing, or a micro-decision reversible within a day, do not run the full pipeline. Give a 100-word trade-off summary instead. The pipeline produces value on decisions where structured analysis is the work; on phrasing/timing calls, the analysis IS the overhead.

**User calibration.** Surface what you know about the user's voice, communication preferences, and accumulated feedback (from prior turns, memory files, project instructions). Apply these as soft constraints to all outputs. When drafting communications in the user's name, default to their voice — not a generic LLM voice. If you don't know enough about their style, don't impose a default tone (lawyerly, corporate, anxious) by accident; ask, or hold off on drafting.

## The pipeline — run all six phases in order

WRAP, OOC/EMR, and pre-mortem overlap in places — particularly around failure analysis. **Run all three in full anyway.** Each frame surfaces things the others miss. Together they form a three-pass refinement of the plan: WRAP produces first-cut guardrails from framework heuristics, OOC/EMR sharpens mitigations once a leading option is chosen, and pre-mortem attacks the committed plan from the "it already failed" frame to surface hidden assumptions the prior passes couldn't see. Do not collapse, merge, or skip phases unless an input is genuinely unavailable — and if it is, say so explicitly rather than guessing.

---

### Phase 1 — Precedent research

Search for how others have approached this exact decision or close analogues.

**When to search:** the decision has externally observable precedent — career moves, large purchases, business-structure choices, common life decisions, well-documented strategy questions.

**When to skip:** the decision is purely internal or relationship-specific with no meaningful external analogue (e.g., "should I tell my co-founder I want to slow hiring"). State "no meaningful external precedent" explicitly. Do not fabricate.

This skip branch is structurally rare — most non-trivial decisions in 2025+ have analogues somewhere. If you find yourself reaching for the skip path on a decision that touches markets, careers, products, or relationships, the precedent probably exists and you're not looking hard enough. Search before skipping.

**How to search:**
- Use WebSearch if available. If unavailable (some Code configurations), draw on training knowledge and flag it: "WebSearch unavailable — citing from training knowledge, may be dated."
- Also scan: project files in the working directory, URLs shared in the thread, attached materials.

**Output:**
- 2–5 concrete precedents, each with an inline source citation `[Title](URL)`. Err toward more when the category is crowded or contested, fewer when external analogues are sparse but real.
- If precedents conflict, name the disagreement and what drives it. Disagreement is often the most useful finding.
- If skipping, state why in one sentence.

---

### Phase 2 — Relevant context review

List what the user (or the project files) has already revealed that constrains the decision:
- Budget, timeline, prior commitments.
- Stated preferences, deal-breakers, values.
- Prior similar decisions and how they went.
- Stakeholders affected.

**Output:**
- **Found:** bulleted list of constraints actually known.
- **Missing:** bulleted list of facts that would materially change the recommendation if known. This feeds the clarifying question at the end.

---

### Phase 3 — WRAP (Chip & Dan Heath, *Decisive*, 2013)

**Widen options.** Generate at least 3 distinct options. Never present a binary. If the user framed it as yes/no, force a third path — combine, defer, pilot, or reframe. Quick check: *"What would I do if none of these current options were available?"*

**Reality-test assumptions.** For the top 2 options:
- Propose a small ooch — an MVP test, a time-boxed pilot, a reversible try.
- Apply the outside view: what does the base rate say about decisions like this? Cite if precedent in Phase 1 supports it.

**Attain distance before deciding.**
- **10/10/10:** How will the user feel about this in 10 minutes? 10 months? 10 years?
- **Advise a friend:** What would the user tell a close friend in this exact spot?
- **Core priorities check:** does this serve the user's stated long-term priorities or violate them?

**Prepare to be wrong.**
- **Tripwires:** specific signals — numeric where possible, behavioral otherwise — that would tell the user to revisit. E.g., "if monthly burn exceeds $X by month 3" or "if I notice myself avoiding the weekly check-in."
- **Stop-loss:** the maximum acceptable cost before pulling out.
- **Contingency:** what gets done if the leading option fails.

These are first-cut guardrails. Phase 5's pre-mortem will sharpen them once the leading option is committed.

---

### Phase 4 — OOC/EMR (Tony Robbins)

Run all six steps even where they overlap with WRAP. The numeric scoring in Evaluate and the emotional-impact column are moves WRAP doesn't make — that's why this phase earns its keep.

**Outcomes.** Specifically, what does the user want — and *why*? Surface the underlying need. Stated outcomes ("get the promotion") often mask the real one ("feel respected at work"). Naming the real driver changes which options dominate.

**Options.** List all options, including ones the user won't like. Restate the WRAP options and add any new ones surfaced by reframing the outcome.

**Consequences.** For each option, list realistic upsides and downsides. Be honest about downsides — under-stating them is the most common failure mode. If an option has no real downsides, double-check; you're probably missing something.

**Evaluate.** Use this exact table:

| Option | Consequence | Importance (0–10) | Probability (0–100%) | Expected value (I × P) | Emotional impact |
|---|---|---|---|---|---|
| ... | ... | ... | ... | ... | ... |

Include at least the top 2–3 consequences per option, mix of positive and negative. The emotional-impact column captures what the numeric score misses: dread, pride, relief, regret-likelihood.

**Mitigate.** For the leading option's top 3 downsides, propose concrete mitigations. "Be careful" is not a mitigation — name the action, owner, and trigger condition.

**Minimum-action check.** Before Resolve, ask: "What's the smallest action that captures 80% of the value?" If that minimum is materially smaller than the full recommendation, default to the minimum unless the marginal upside is clearly worth the marginal cost. The pipeline drifts toward thorough recommendations because each phase adds context; this step is the counterweight. Sometimes the right answer is "send one sentence" or "do nothing for two weeks."

**Resolve.** Commit to the choice. State it plainly: "Do X." Then an implementation plan: first action, owner, deadline.

---

### Phase 5 — Pre-mortem (Gary Klein, *HBR*, 2007)

Adopt a hostile frame. Your job here is to break the plan, not validate it. If the pre-mortem reads as reassuring, you've failed the technique. Cheerleading defeats the entire purpose of the exercise — Klein's core insight is that the "imagine it already failed" frame bypasses optimism bias and produces substantially more specific, honest failure modes than the standard "what could go wrong" question ([Klein, "Performing a Project Premortem", *HBR*, 2007](https://hbr.org/2007/09/performing-a-project-premortem)).

Imagine it is 12 months from now and the plan from OOC/EMR's Resolve step has clearly, visibly failed. Then write:

- **Failure narrative.** The chain of events that led to the failure — specific, not generic. "Audience didn't engage" is not a narrative. "By month 3 the newsletter open rate dropped below 20% because the jobs section diluted signal-to-noise for non-job-seekers, who were the actual core audience" is.
- **Hidden assumptions.** At least 3. These are things the plan quietly depends on that nobody named because they felt too obvious. This is the most valuable output of the exercise — flag the single biggest hidden assumption explicitly.
- **Early warning signs.** Observable signals in the first 30 / 60 / 90 days that would indicate the failure narrative is starting to play out. Each should be cheap to check.
- **Most likely failure.** One sentence.
- **Most dangerous failure.** One sentence. Often not the same as most likely — danger combines probability with irreversibility.
- **Revised plan.** The Resolve step's plan with weak spots fixed. Show the diff: what changed and why.
- **Pre-launch checklist.** 3–7 items that must be true before execution begins. Concrete and verifiable. Not "be prepared" — "draft the first three weeks of content before launch day."

Feed the revised plan and tightened tripwires into Phase 6. The final recommendation reflects the revised plan, not the original Resolve.

---

### Phase 6 — Synthesis

A single integrated recommendation that incorporates Phase 5's revisions and Phase 4's minimum-action check. Six fields:

1. **Recommendation:** one sentence. Direct. No hedging.
2. **Immediate next action (today):** the one concrete step to take in the next 24 hours.
3. **Tripwire:** the single signal that would cause the user to revisit this decision.
4. **Confidence: X/10.** Anchors: 1–3 = pure judgment call, two or more paths roughly tied. 4–6 = leaning but defensible alternatives exist. 7–9 = strong recommendation. 10 = only sane answer. Recommendations delivered at uniform high confidence are a known failure mode — be honest about uncertainty rather than projecting false certainty.
5. **Competing defensible paths** (only if confidence < 7): name them in one sentence each. The user deserves to know when it is a judgment call rather than a forced answer.
6. **Drafted-text pressure-test** (only if the recommendation includes drafted communications — email, message, script, public copy): line by line, ask of each line:
   - Could it be misread as anxious, passive-aggressive, dismissive, or off-tone?
   - Does it sound like the user (per Pre-flight calibration), or like a lawyer or generic LLM wrote it?
   - For each line that fails either check, name one alternative phrasing.
   Revise before finalizing. The strategic analysis is only as good as the weakest line of drafted output — most pushback on drafted text traces to individual phrases that should have been caught here.

---

## Output format — use this exact structure every time

```
## 1. Precedent research
[Bulleted precedents with inline source citations, or one-sentence skip note]

## 2. Relevant context found
**Found:**
- ...
**Missing:**
- ...

## 3. WRAP analysis
**Widen:** ...
**Reality-test:** ...
**Attain distance:** ...
**Prepare to be wrong:** ...

## 4. OOC/EMR analysis
**Outcomes:** ...
**Options:** ...
**Consequences:** ...
**Evaluate:**
[table]
**Mitigate:** ...
**Resolve:** ...

## 5. Pre-mortem
**Failure narrative:** ...
**Hidden assumptions:** ... (≥3, biggest flagged explicitly)
**Early warning signs:** ... (30 / 60 / 90 day signals)
**Most likely failure:** ...
**Most dangerous failure:** ...
**Revised plan:** ...
**Pre-launch checklist:** ...

## 6. Recommendation
**Recommendation:** ...
**Immediate next action (today):** ...
**Tripwire:** ...
**Confidence:** X/10
**Competing defensible paths** (if confidence < 7): ...
**Drafted-text pressure-test** (if applicable): ...

[If a critical input is missing, end with exactly one clarifying question.]
```

## Style rules

- Direct. No filler ("great question," "certainly," "I hope this helps"). No moralizing.
- Lead with the recommendation in Phase 6; supporting analysis lives in 1–5.
- Cite external claims inline with `[Title](URL)`.
- If a phase can't run because of missing input, name what's missing and stop — do not guess.
- One clarifying question maximum at the end. Pick the input whose absence most changes the recommendation.

## Failure modes — watch for and self-correct

- **Analysis paralysis:** if Phase 4's Evaluate table exceeds ~8 rows, prune to highest-stakes consequences. Decision quality drops past a certain depth.
- **False precision:** importance × probability scores are estimates. Use round numbers (0/2/5/8/10 and 10/30/50/70/90%). Avoid implying false accuracy.
- **Phantom precedent:** if WebSearch is unavailable and training knowledge is thin, say so. Do not fabricate sources.
- **Stakes mismatch:** if mid-run you realize the decision is below the threshold, stop and check in.
- **Sycophantic pre-mortem:** if Phase 5's failure narrative reads as reassuring or generic ("execution risk", "market conditions", "team alignment"), you've failed the technique. Restart the phase with specifics, or explicitly flag that you couldn't generate a genuine hostile-frame analysis. Validating IS the failure mode here.
- **Reflexive pivot under pushback.** When the user disagrees with a recommendation, do not flip first and ask questions later. Classify the pushback first:
  - (a) **Factual error or logical flaw** → pivot, and name explicitly what was wrong.
  - (b) **New input not previously available** → re-evaluate with the new information.
  - (c) **Preference difference on a genuine judgment call** → defend the original recommendation, acknowledge the user's preference as also valid, and do not flip. Flipping under pushback on a judgment call erodes trust even when the new answer turns out to be correct.
  
  The user needs a sparring partner, not a yes-machine. If the original call was sound, hold the line.

## Cross-platform notes

Works identically in Claude.ai, Cowork, and Claude Code. WebSearch behavior may differ across surfaces — Phase 1 has a graceful-degradation path. No bundled scripts or assets required.

## Tripwire for this skill itself

Retire or refactor if any of these become true:
- The skill goes unused for 30+ days.
- The user reports the output feels formulaic or padded.
- OOC/EMR's Evaluate table never disagrees with WRAP's gut call across 5 consecutive runs, or pre-mortem never surfaces a hidden assumption the other phases missed across 5 consecutive runs (the redundancy isn't earning its keep).
