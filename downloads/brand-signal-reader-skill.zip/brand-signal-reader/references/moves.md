# The seven moves

Context for action items, not a menu. An action item starts from a row or pattern in the data and says what the brand could do about it. These seven moves are the kinds of things a brand can do once it knows the job behind its name. Read them so the action items have range; don't write "Move 3: loyalty" as an action item, and don't try to cover all seven.

This file was drafted from the move names and the action items in the essay's four brand sections. If the essay's own text for the moves says something different, the essay wins.

## 1. Brand marketing

Make the name mean one thing people can remember and search for. Skyscanner's "Dallas to Cancun" billboard paired the name with a route; DoubleTree's cookie paired the name with something people take home.

Signal in the data: rows where the brand name is paired with a need ("skyscanner charlotte", "booking.com chicago"), and link rows where a campaign or a memorable detail earned coverage.

An action item it informs: "Pair your brand name with the trip (or product, or outcome) you want people to find, and put that pairing in campaigns so the search exists before you rank for it."

## 2. Competitor mention benchmarking

In AI answers the brand gets named next to rivals even when it's already in the question. The job is to be the one the answer prefers, and to know when it isn't.

Signal in the data: prompts that compare the brand with competitors ("choosing between Wyndham, IHG, and Marriott"), prompts that compare where to buy ("different travel sites"), and trust prompts that lump the brand with a category ("sites like Booking.com or Hotels.com").

An action item it informs: "Make the reasons to choose you over the two names that keep appearing next to yours easy for an answer engine to find and quote: one page, plain claims, current."

## 3. Loyalty

A program gives people a reason to come back between purchases and gives publishers something to explain. It also creates jobs of its own: login, points value, transfers, the card.

Signal in the data: program and account rows ("hilton honors", "ihg login", "booking genius levels"), card and points rows ("ihg credit card", "buy hilton points"), benefit-coverage prompts ("Can I use IHG points at Iberostar"), and links from loyalty publishers.

An action item it informs: "Pick the one benefit you want people to remember, say it the same way across every brand you own, and make sure the login, points and card pages each finish the job they're searched for."

## 4. Trend marketing

Publish what you know. Research, predictions and data give news outlets and guides a reason to cite the brand to an audience that isn't shopping yet.

Signal in the data: link rows where research or data earned coverage (Booking.com's Travel Predictions on Good Morning America, Skyscanner's Smarter Summer Report in Travel + Leisure).

An action item it informs: "Turn one question your customers keep asking into a dated report with a method section, and give it a page publishers can link to."

## 5. Task completion

Each job needs a page that finishes it. Someone searching the wifi, the cancellation policy or the flight status isn't shopping; they want to be done.

Signal in the data: access-during-use rows ("hilton wifi"), support rows ("booking.com customer service number"), policy rows ("booking.com cancellation policy"), help-during-use prompts, and links to pages someone had to link to (event booking, flight status).

An action item it informs: "List the jobs in the table, check there's one page for each, and measure whether people finish the job there instead of calling or leaving."

## 6. Experimentation

Test a benefit, a partner perk or a named tool before building it out. Agree who funds it, who delivers it and how you'll know it worked, especially when the checkout happens somewhere else.

Signal in the data: named-feature rows and prompts ("skyscanner price alert", "How does the Skyscanner savings generator work?"), partner links (Emirates, McLaren), and compare-where-to-buy prompts that show the brand losing the booking after winning the choice.

An action item it informs: "Pilot one member perk with one partner for one quarter, with the qualifying rule written down before launch."

## 7. Personalization

Different people use the name for different reasons: a guest, a member, a business buyer, a partner, a journalist. Serve the audience the row reveals rather than the average visitor.

Signal in the data: business and partner prompts ("IHG Business Edge for my company", "become an IHG partner"), audience-specific policy links (Kimpton's pet policy on the American Kennel Club site), and sub-brand rows that show which audience each sub-brand pulls.

An action item it informs: "Pick one audience the rows show you're already attracting and remove one thing that frustrates them, through the product, a policy or a page written for them."
