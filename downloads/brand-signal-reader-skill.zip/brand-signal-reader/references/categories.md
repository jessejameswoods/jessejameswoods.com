# Job labels

Every row gets one label. A label is the job the person is trying to get done, written so it works for a hotel group, a bank or a software company. The travel examples are rows from the essay's four brands (IHG, Hilton, Booking.com, Skyscanner). The non-travel examples show the same job in another industry; they're illustrations, not rows from a file.

When a label holds more than half the rows in a file, split it into sub-jobs and say so in the reading. When a row fits nothing here, add a label, write it as a job, and say it's new.

## Keyword jobs

What someone is searching for.

| Job | What it covers | Travel example | Non-travel example |
|---|---|---|---|
| The brand itself | The name alone, the domain typed as a search, a misspelling, "what brands does it own", "what is it" | `ihg`, `booking.com`, `sky scanner`, `ihg brands` | `chase`, `ikea.com`, `is insurify an insurance company` |
| A product, service or location under the brand | A sub-brand, a product line, a named hotel, store or office | `holiday inn express`, `embassy suites`, `hilton hawaiian village`, `skyscanner flights` | `chase sapphire`, `ikea billy bookcase`, `apple watch ultra` |
| A nearby or local version | Brand plus "near me", a city or a region when the job is to find one close by | `hilton near me`, `holiday inn express near me` | `ikea near me`, `chase bank near me` |
| A membership or loyalty program | The program by name, its tiers, how it works | `hilton honors`, `ihg rewards`, `booking genius`, `booking genius levels` | `amazon prime`, `sephora beauty insider`, `starbucks rewards` |
| An account or login | Signing in, managing the account, resetting a password | `ihg login`, `hilton honors login`, `booking extranet` | `netflix login`, `chase online banking login` |
| A payment or card product | A co-branded card, buying points, financing | `ihg credit card`, `buy hilton points` | `apple card`, `ikea credit card`, `affirm at walmart` |
| Support | Help, contact, a phone number, a complaint | `booking.com customer service number`, `booking customer service` | `spotify customer service`, `contact dyson` |
| A discount or promo | A code, a sale, a student or member rate | `booking.com promo code` | `nike promo code`, `hellofresh discount` |
| A policy or terms question | Cancellation, returns, shipping, fees, guarantees | `booking.com cancellation policy` | `zara return policy`, `ikea delivery cost` |
| The app | Getting, using or fixing the app | `skyscanner app` | `duolingo app`, `chase app not working` |
| The brand paired with a need | Brand plus a destination, product category or use case; the person wants the brand to do a specific thing | `booking.com chicago`, `skyscanner charlotte`, `skyscanner multi city flights`, `booking car rental` | `ikea kitchen planner`, `canva resume`, `uber airport` |
| Access during use | Something needed once the person is already a customer or on site: wifi, check-in, setup, status | `hilton wifi`, `skyscanner flight status` | `ring doorbell setup`, `peloton wifi`, `fedex tracking` |
| A named feature or tool | A feature inside the product that people remember and search for by name | `skyscanner price alert`, `skyscanner explore everywhere` | `spotify wrapped`, `canva magic studio`, `gmail confidential mode` |
| Reviews or whether to trust it | Reviews, "legit", "safe", complaints, scam | `skyscanner reviews`, `booking.com reviews` | `temu reviews`, `is wise legit` |
| The company behind the brand | Careers, jobs, news, stock, owner, CEO, logo | `booking.com careers`, `ihg jobs`, `booking.com news` | `ikea jobs`, `who owns wise`, `spotify stock` |
| Working with the brand | Partner, affiliate, supplier, API, extranet, travel agent access | `booking.com affiliate program`, `booking.com api`, `booking extranet` | `shopify partners`, `amazon seller central` |
| The right country or language edition | Brand plus a country, language or regional site | `skyscanner usa`, `skyscanner español`, `skyscanner uk site` | `ikea canada`, `zara mexico` |
| Opening hours or whether it's open | Hours, holidays, open now | (not in the essay exports) | `ikea hours`, `is ikea open on easter` |
| Staff access or employee use | A staff rate, an internal system, team-member travel | `go hilton`, `hilton lobby`, `hilton team member travel` | `walmart one`, `my lowe's life` |

The first two of the added labels came from Skyscanner's export; the rest were added after test runs on IHG, Hilton, Booking.com, Skyscanner, IKEA and Insurify found the same jobs with no home.

## Prompt jobs

What someone is trying to do with the answer they get.

| Job | What it covers | Travel example | Non-travel example |
|---|---|---|---|
| Compare the brand with competitors | The brand is in the question alongside rivals | "What factors should I consider when choosing between Wyndham, IHG, and Marriott hotels?" | "Is Notion or Confluence better for a 50-person team?" |
| Decide whether to sign up, apply or buy | Should I join, apply, subscribe, purchase | "What should I consider before applying for the IHG credit card?" | "Is the Apple Card worth it if I already have a Chase Sapphire?" |
| Check whether a benefit covers a specific case | Does the program, warranty, policy or benefit apply to my situation | "Can I use IHG points at Iberostar beachfront resorts?" | "Does AppleCare cover a cracked screen if I dropped it?" |
| Choose within the brand | Which of the brand's own options fits | "Can you recommend the top Hilton Garden Inn hotels in Cincinnati for families?" | "Which Dyson vacuum is best for pet hair?" |
| Compare where to buy it | The brand is chosen; the channel isn't | "How do the prices compare for booking Hilton Home2 Suites Walpole Foxboro on different travel sites?" | "Where's the cheapest place to buy a Dyson V15?" |
| Plan around using it | Things to do, eat or arrange around the product or stay | "What are the best restaurants near Hilton Midtown in NYC?" | "What's a good 30-minute Peloton class to do before work?" |
| Get help during use | Troubleshooting, logging in, something not working while using it | "What are the steps to log into Marriott or Hilton WiFi networks?" | "How do I reset my Sonos speaker?" |
| Check how to pay | Payment methods, deposits, instalments, currencies | "What are the different payment options available on Booking.com?" | "Can I pay for an Ikea order with Klarna?" |
| Check whether it's trustworthy | Legitimacy, safety, reliability of prices or service | "How can I tell if a hotel booking site like Booking.com or Hotels.com is trustworthy?" | "Is Temu safe to order from?" |
| Find a discount | Codes, deals, cheaper ways in | "How can I find the best discount codes for booking.com?" | "How do I get a Nike student discount?" |
| Evaluate for business or partner use | Using the brand for a company, or working with it as a partner, affiliate or supplier | "What are the benefits of IHG Business Edge for my company?", "How can I become an IHG partner or affiliate?" | "Does Slack have a plan for a 200-person company?", "How do I become a Shopify partner?" |
| Use or understand a named feature | How a specific feature works or how to use it | "How does the Skyscanner savings generator work?", "Can I set alerts on Skyscanner for flights to Salt Lake City?" | "How does Spotify's AI DJ pick songs?" |
| Learn how to do something in it | A how-to with no named feature; the person already uses the product | "How do I find hotels in Destin with jacuzzi tubs on booking.com?" | "How do I set up a CRM in Notion?" |
| Check whether it can do a specific thing | A capability question before or during use | "Can I book cruises through IHG?" | "Does Notion work offline?" |
| Look up one named product or location | The brand's own named thing, asked about on its own | "holiday inn san antonio riverwalk an ihg hotel photos" | "ikea billy bookcase dimensions" |
| Use the brand as a source to judge something else | The brand's reviews, ratings or data used to evaluate a third thing | "How do reviews of Moxy Bergen compare on TripAdvisor and Booking.com?" | "What does Glassdoor say about working at Deloitte?" |
| Learn about the company behind the brand | Ownership, leadership, stock, layoffs, ads | "Who is Glenn Fogel and what is his role at Booking.com?" | "Who owns Wise and is it profitable?" |

The named-feature label came from the Skyscanner export; the five after it were added after test runs on IHG, Hilton, Booking.com and a Notion prompt list found the same jobs with no home.

Prompt exports often contain short, keyword-shaped prompts ("ihg card", "www skyscanner net") next to full questions. Label them the same way; they're what people typed.

## Link jobs

What stood out: the reason a page had to link to the brand.

| Job | What it covers | Travel example | Non-travel example |
|---|---|---|---|
| A benefit publishers explain | Loyalty, status, points, a perk worth a guide | The Points Guy and Frequent Miler explain IHG One Rewards changes and link to the program page | NerdWallet explains Chase Ultimate Rewards and links to the program page |
| A partnership page | A commercial partner describes the relationship and links | Emirates' InterContinental partner page; McLaren's "Hilton For the Stay" page | Starbucks' page about its Spotify partnership |
| A useful feature, amenity or policy | Something practical a third party has reason to point at | Tesla's charging locations at Crowne Plaza Alice Springs; the American Kennel Club on Kimpton's pet policy | A cycling blog links to Trek's lifetime frame warranty page |
| A page someone had to link to | Booking, event, documentation; the link exists because the task needs it | PATA Travel Mart links to a Hilton Kuching event-booking page; an airport links to Skyscanner's flight-status page | A conference links to its Eventbrite ticket page; a developer blog links to Stripe's API docs |
| Research or data the brand published | Reports, predictions, surveys other sites cite | Good Morning America cites Booking.com's 2026 Travel Predictions; Travel + Leisure cites Skyscanner's Smarter Summer Report | A news site cites Duolingo's annual language report |
| A campaign that earned coverage | Advertising or a stunt that became a story | FOX 11 covers Skyscanner's Dallas to Cancun billboard and links to the homepage | Coverage of a Liquid Death ad links to the brand's site |
| A tool with a name | A named tool recommended by its name | Condé Nast Traveler links to Skyscanner's Savings Generator; Frequent Miler links to Hilton's Points Explorer | A productivity blog links to Notion AI |
| Recognition the linked site displays | A badge, award or listing the other site shows off | Visit Waco displays a Booking.com most-welcoming-destinations badge | A local plumber displays a Yelp award badge |
| An affiliate recommendation | A recommendation with a commission behind it | Nomadic Matt's Boston guide recommends Booking.com through an affiliate link | A tech blog recommends Shopify through an affiliate link |
| Something people remember and share | A detail from the experience that travels outside the category | Food sites such as The Kitchn link to the DoubleTree cookie recipe | Recipe sites link to the original Toll House cookie recipe on Nestlé's site |

| A ranking or award that names the brand | The other site publishes a list or award and the brand is on it; the reverse of a badge the brand hands out | Great Place To Work's Best Workplaces in Australia list links to Hilton's corporate page | A "best banks" roundup links to Chase |
| A local sponsorship or community listing | A team, school, charity or venue names the brand as sponsor or host | A minor-league team's site links to the DoubleTree Cedar Rapids page | A youth soccer club's sponsors page links to a local credit union |
| A review, warning or news story about the brand | The brand is the subject, not the source: a review, a privacy warning, funding or layoff coverage | (not in the essay exports) | Consumer Reports' piece on quote-comparison sites' privacy links to insurify.com; TechCrunch covers a funding round |

The "something people remember" label was added for the DoubleTree cookie, which isn't a campaign, a feature or a policy. It's the thing people took home. The three after it came from Hilton and Insurify backlink exports read during testing.

Links from the brand's own domains (gift-card sites, sub-brand sites, foundation pages) aren't a job anyone else had. Skip them and say so.
