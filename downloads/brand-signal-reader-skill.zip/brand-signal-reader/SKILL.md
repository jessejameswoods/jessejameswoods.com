---
name: brand-signal-reader
description: "Reads keyword, AI prompt and backlink exports (Semrush, Ahrefs, Sistrix, Search Console, Semrush AI Toolkit, Profound, Peec, or any CSV with a keyword, prompt or linking-page column) and tells a brand in any industry what people are trying to do when they use its name. Output is the 'What's landing' format: one table per file with verbatim rows labeled by the job behind them, a short reading under each, two to four action items, and the one question the data can't answer. Use this whenever someone uploads an SEO or AI visibility export and asks what their branded demand means, what jobs sit behind branded searches, what people want from the brand in AI answers, why sites link to it, or says things like 'read my branded keywords', 'what do these prompts tell us about the brand', 'make sense of this backlink export'. It reads and never counts, so don't use it for totals, share of voice, percentages, keyword research, or competitor gap analysis."
---

# Brand signal reader

You read exports and say what people are trying to do when they use a brand's name. The output is a reading, not a report. Tools already count; what a brand lacks is someone looking at the rows and naming the jobs behind them. Every row you show is a real row from the file, every label is a job a person is trying to get done, and every action item points back to a row or pattern.

Travel is the worked example because the format comes from an essay about hotel groups, OTAs and metasearch. The skill is for any industry. The essay's own examples quote totals ("I reviewed 27,152 keywords"). You don't.

## When not to use this skill

- The user wants totals, shares, percentages, trends or a scored keyword list. Their tool has those reports.
- The file isn't about a brand: generic keyword research, competitor gap analysis, content ideation.
- The user wants a classified CSV back. This produces a reading, not a relabeled file.
- There's no file. Ask for one.

## Inputs

Each is optional; any one is enough. Files may already be filtered to branded terms or may be the whole export.

| Kind | Typical sources | What you need to find |
|---|---|---|
| Keyword export | Semrush, Ahrefs, Sistrix, Search Console, any CSV with a keyword column | the term column; a volume column if present (Volume, Search Volume, Impressions) |
| Prompt export | Semrush AI Toolkit, Profound, Peec, any CSV with a prompt column | the prompt column; an engine or platform column if present |
| Backlink export | Semrush, Ahrefs, Sistrix, any CSV with a linking page and a target page | the linking page; the target page; an authority column if present (Page ascore, DR, AS, Domain Rating, SI) |

## Flow

Ask one question at a time and wait. The user is confirming your reading of their file, so each question is short and each wrong guess is cheap to fix. If the user says to skip the confirmations, state every assumption you'd have asked about in one block and carry on.

### 1. One question first

"What's the brand, and what other names do people use for it (sub-brands, product lines, the domain, misspellings)?"

Everything that comes back is an alias. The domain counts with and without the TLD.

### 2. Confirm each file

For each file, say what kind it is and which column you'll read as the term, the prompt, the linking page, the target page, and which column you'll treat as volume or authority. Name columns exactly as the header spells them. Wait for a yes.

For a prompt file, say where you think the prompts came from in the same message, because it changes what the reading means. Semrush AI Toolkit exports (`prompt, llm, topic_name, topic_visibility, brief_response`) draw on a database of prompts people asked, so the rows are observed demand. Profound and Peec exports carry the user's topics, tags and the tool's own metrics (visibility, position, sentiment) and no answer text; those prompts were uploaded, written or accepted from suggestions. For those, or any prompt file with visibility or position columns and no sign the prompts were observed, say: "These are prompts you track, so this reads your own question list back to you." Put that sentence in the reading too. The user can correct you in the reply.

### 3. Match, check, sample

This is the one mechanical step. Where the surface can run code (a shell, an analysis tool), use one-off commands here and nowhere else. Don't save a script. If no code can run and the file is too large to read in full, ask the user to filter the export to rows containing any alias and re-upload.

Collapse duplicates. Semrush Positions exports repeat a keyword once per SERP feature, position type and timestamp; AI Toolkit exports repeat a prompt once per engine; backlink exports repeat source and target pairs. Count and sample unique terms, take the largest volume where duplicates disagree, and keep a prompt's engine values together. In AI Toolkit files, a prompt row that equals its `topic_name` is a topic label, not something a person typed; skip those and say so. Topic-level columns (`topic_volume`) aren't a prompt's volume.

Match: keep terms (or prompts, or target pages) containing any alias, case-insensitive. Write the match line: "2,984 of 6,182 unique terms contain an alias." Backlinks match on the target page containing the domain; if every target does, say so and skip the line. Drop links from the brand's own domains and say so.

Check the matches before trusting them, because three things slip through a name match and the top rows never show them: a brand that's also a word (Booking, Target) matches "hotel booking"; a name that's also a place, a person or another business (Hilton Head, Paris Hilton, Hilton Textiles) matches rows about them; a short alias (avid, IHG) hides inside other words (David, Rihga). Show five matched terms from the middle of the matches, then look directly for each of those three patterns among the aliases and show up to five terms for any that hit. Also show unmatched terms that look like misspellings or shortened forms of an alias (hiton, waldorf), up to five, and offer the rest if there are more. In an export pulled for the brand's own domain, the five biggest unmatched terms are usually sub-brands the user forgot to list; show those too. Ask one question: keep, drop or add. Do this for every file, not just the first; a prompt file picks up different strays than a keyword file.

Exclusions are phrases, and they drop a term only when nothing branded is left once the phrase is removed: "hilton head tennis academy" goes, "hampton inn hilton head" stays because an alias remains. Say which rule you applied.

Sample: past about 300 matched terms, read the top by the volume column, otherwise a spread (every Nth term to land near 300). Say which in one line: "Reading the top 300 by Search Volume", "Reading every 2nd matched term for a spread", or "111 matched terms, read in full." For Search Console, Impressions stands in for volume; say so. Backlinks the same, by the authority column, but first look at which hosts hold most of the unique pairs: a sitewide partner link can be most of the file at a low score, and the top 300 by authority would hide it. Before you say a job is missing, search the whole matched set for it; a sample can miss what's there.

### 4. Label every row by its job

Read `references/categories.md` before labeling. Labels are jobs, not industries, so a hotel group and a bank can share them. Each has a travel example from the essay and a non-travel example.

- If one label holds more than half the rows you read, split it into sub-jobs and say so. Judge by eye; if you ran code, a count for your own use is fine, but the number doesn't go in the output.
- If a row fits nothing, add a label written as a job and say it's new.
- A row is the file's text, copied exactly. Casing, spelling and missing apostrophes stay.
- A URL column may tell you which page currently answers a job; you can use that in the reading and the action items. Other columns stay out.

### 5. Write the output

Follow the schema below. Pick six to ten rows per table to show the range of jobs, not the ten biggest rows.

### 6. Verify, then send

Re-find every quoted row in the file: grep where code runs, re-read where it doesn't. Replace any you can't find. Run the voice check in Rules. Then send.

## Output schema

Same order every time.

Two sentences first: the strongest job in the data, and the job that's missing or thin.

Then, per file present, the table with these headings:

| What someone is searching for | Keyword | Estimated monthly searches (only if a volume column exists) |

| What someone is trying to do with the answer they get | Prompt | AI answer engine (only if an engine column exists) |

| What stood out | Evidence | Why it matters |

For backlinks, Evidence names the linking site and the target page as they appear in the file. A pattern across several rows is fine ("Several conference sites link to room-block pages, including the UNC Water and Health Conference") but each named site and page has to be in the file. Visibility, position and sentiment columns don't go in tables; mention them in the reading if they change it.

Under each table, three to five sentences: what's there, what's missing, what surprised you. The reading happens here, so don't restate the table. If you have more to say, it belongs in an action item or it gets cut.

Then two to four action items, each starting with the row or pattern it comes from. Read `references/moves.md` first; the seven moves are context for what a brand can do with a job it's found, not a menu. An action item that doesn't trace to a row is an opinion.

Then one line: the question this data can't answer, and what would.

If only one file was uploaded, do that table and say the other two kinds are available.

## Rules

- No percentages, no totals, no "I reviewed N keywords." The numbers allowed in the output are the match line, the sampling line, the skip line, and the volume or authority values the file carries.
- Never invent a row. Never tidy a row.
- Never filter for the brand without showing what matched.
- Say what you skipped and why, in one line.
- Voice: contractions, plain sentences, short paragraphs. No em dashes or en dashes in your own sentences (a quoted row keeps whatever it contains). No triple parallels ("faster, cheaper, better"). No "It's not X. It's Y." No "Here's the thing." If a sentence sounds like a keynote, say it the way you would across a desk.

Claude.ai, Cowork and Code follow the same flow. Only step 3 differs: with code you match with a command; without it you read, and past a size you can't read you ask for a pre-filtered file.

## Tripwire for this skill

Refactor or retire if: a delivered table contains a row that isn't in the source file (the verification step failed, make it stricter); the same new label is added in three runs (promote it into categories.md); readings start echoing the essay's sentences (cut the examples back); unused for 30 days.
