# Brand signal reader test run: Hilton (v2)

User message: "Hilton keyword and prompt exports. What are people trying to do with the Hilton name?"

Files: /home/claude/bsr-tests/hilton-keywords.csv, /home/claude/bsr-tests/hilton-prompts.csv

---

## Step 1. One question first

Q (skill): What's the brand, and what other names do people use for it (sub-brands, product lines, the domain, misspellings)?

A (user): Hilton. Hilton Honors, DoubleTree, Embassy Suites, Hampton, Homewood Suites, Home2 Suites, Tru by Hilton, Waldorf Astoria, Conrad, Canopy, Curio, Tapestry, LXR, Motto, Signia, Tempo, Spark, Graduate, hilton.com.

(All of these are aliases. hilton.com counts with and without the TLD, so "hilton" covers it.)

## Step 2. Confirm each file

Q (skill): hilton-keywords.csv is a Semrush organic Positions export. I'll read `Keyword` as the term and `Search Volume` as the volume. I'll use `URL` only to see which page currently answers a job. Is that right?

A (user): yes

Q (skill): hilton-prompts.csv is a Semrush AI Toolkit prompt export (columns `prompt, country, llm, categories, topic_id, topic_name, topic_volume, topic_intents, topic_visibility, topic_difficulty, brief_response, mentioned_brands_count, sources_count`). I'll read `prompt` as the prompt and `llm` as the engine. Because this is an AI Toolkit export with `brief_response` text, I'm treating the rows as prompts people actually asked, so the reading is observed demand, not a list you track. Is that right?

A (user): yes

## Step 3. Match, check, sample

### Keyword file

Collapsed duplicates: the Positions export repeats a keyword once per position type, so I kept one row per keyword and took the largest Search Volume where they disagreed.

Match line: 32,672 of 36,724 unique terms contain an alias.

Five matched terms from the middle of the matches:
- hilton garden inn in gallup new mexico
- hilton medford
- hilton doubletree costa rica san jose
- hilton hotel galveston seawall
- hilton hononrs

Checks for the three things a name match lets through:

A name that's also a place or a person (Hilton Head, Paris Hilton):
- hilton head island hilton head island sc
- hilton head south carolina hotels
- hampton inn hilton head
- hilton in hilton head island sc
- paris hilton hotel

A brand that's also a word (Hampton, Conrad, Canopy, Curio, Tapestry, Motto, Tempo, Spark, Graduate): I looked at each without "hilton" in the term. Every one I checked lands on a hilton.com hotel page, so they're the sub-brands, not the words. The closest to strays:
- hamptons sherman oaks (lands on Hampton Suites Los Angeles)
- embassy suites hampton va (Hampton the city, but Embassy Suites is in the term)
- conrad hilton hotel chicago (the founder's name, but it lands on Hilton Chicago)
- sparks hotel las vegas
- the graduate ann arbor (a Graduate hotel)

A short alias hiding inside other words (LXR): the only hits are the LXR hotels themselves ("ka la'i waikiki beach lxr hotels & resorts"). Nothing stray.

Unmatched terms that look like misspellings or shortened forms of an alias:
- hiton
- hitlon
- hiltom
- double tree by hilton
- home 2 suites near me

(Also unmatched and worth knowing about: "waldorf orlando", "homewood hotel nyc", "embassy suite", which are shortened names rather than misspellings.)

Q (skill): Keep, drop or add? Specifically: should I drop the Hilton Head rows and the Paris Hilton rows, keep the Conrad, Hampton and Graduate rows since they land on your hotel pages, and add "hiton", "hitlon", "hiltom", "double tree", "home 2 suites", "embassy suite", "waldorf" and "homewood" as aliases?

A (user): Drop Hilton Head, it's an island, and drop Paris Hilton, she's a person. Keep Conrad, Hampton and Graduate as you describe. Yes, add all of those misspellings and the shortened forms as aliases.

Exclusion rule applied: "hilton head" and "paris hilton" are phrases. A term drops only when nothing branded is left once the phrase is removed. So "hilton head island hilton head island sc" and "paris hilton hotel" go, and "hampton inn hilton head" and "hilton in hilton head island sc" stay because an alias remains.

Match line after the aliases were added and the exclusions applied: 33,206 of 36,724 unique terms contain an alias.

Sampling line: Reading the top 300 by Search Volume.

### Prompt file

Collapsed duplicates: the AI Toolkit export repeats a prompt once per engine, so I kept one row per prompt and kept its engine values together.

Skip line: I skipped 164 unique prompts (196 rows) whose text equals their `topic_name` (topic labels like "Hilton Head Golf Packages and Resorts", not something a person typed).

Match line: 715 of 715 unique prompts contain an alias. The file arrived already filtered to the name.

Five matched prompts from the middle of the matches:
- hilton hotel partners
- hilton garden inn sd rancho bernardo
- doubletree hilton orlando downtown
- best shopping on hilton head island
- hilton toronto richmond street west

Checks for the three things a name match lets through:

A name that's also a place or a person: this is where the prompt file picks up strays the keyword file didn't.
- What are the best restaurants and bars to visit on Hilton Head Island?
- Can you recommend the best commercial real estate agents in Beaufort and Hilton Head?
- Where can I buy Paris Hilton perfumes online?
- Gibt es bekannte Fotos oder Artikel über Tessa Hilton auf Getty Images oder anderen Plattformen?
- What are the best places to buy Ty Hilton autographs online?

Other things that carry the Hilton name and aren't the hotel company (same pattern, other businesses and people):
- What types of machinery and equipment does Hilton Power Equipment offer?
- How does Hilton Textiles compare to other textile suppliers?
- Where is the best place to buy Hilton's oyster stew near me?
- Where can I buy authentic Matthew Hilton furniture?
- Are there any recent articles about the earnings of media figures like Steve Hilton?

(Also seen once each: "Where can I find authentic Hilton bowling shirts online?", "Where is the best place to buy vintage Hilton watches online?", "What amenities are offered at Hilton dermatology & aesthetics in Slidell?", "How do Hilton cars compare in price and quality to other UK dealerships?", "What brands of pianos can I buy at Hilton Piano Center?", "Can you recommend apartments in Hilton, NY?", "hiltonheadvacation".)

A brand that's also a word: no prompt uses Hampton, Conrad, Canopy, Curio, Tapestry, Motto, Tempo, Spark, Graduate or Signia without "hilton" next to it.

A short alias inside other words: "Can you tell me about the Hilton at the Ageas Bowl Southampton?" matches on "hampton" inside Southampton, but "Hilton" is in the prompt anyway, so it's a real match.

Unmatched prompts that look like misspellings: none. Every prompt in the file already contains "hilton".

Q (skill): Keep, drop or add? Specifically: drop the Hilton Head prompts, the Paris Hilton, Tessa Hilton, Ty Hilton, Steve Hilton and Matthew Hilton prompts, and the Hilton Power Equipment, Hilton Textiles, Hilton's oyster stew, Hilton bowling shirts, Hilton watches, Hilton dermatology, Hilton cars, Hilton Piano Center and Hilton, NY prompts? Keep the Ageas Bowl one?

A (user): Yes, drop all of those. They're the island, people and other companies. Keep the Ageas Bowl one.

Exclusion rule applied: the same phrase rule. A prompt drops only when nothing branded is left once the excluded phrases are removed. "How do I find the best deals on Hilton Head hotels through travel websites?" goes; "What are the main services offered at Hilton medical centers in Houston and Hilton Head?" stays because "Hilton" remains after "Hilton Head" is removed. One prompt I couldn't show you in the check still slipped through ("What are the best online platforms to learn piano like Bill Hilton?"); I read around it.

Match line after exclusions: 447 of 715 unique prompts contain an alias.

Sampling line: Reading every 2nd matched prompt for a spread. There's no prompt-level volume column (`topic_volume` belongs to the topic, not the prompt), so I didn't rank by it.

Before saying a job was missing I searched the whole matched set of each file for it, not just the sample.

---

## Reading

The strongest job in both files is someone who has already picked a Hilton hotel and wants its page: they type the hotel's name, its street address or its airport, and in AI engines they ask what's near it. The job that's thin is deciding: almost nobody asks whether to join Honors, whether the card is worth it, or whether Hilton can be trusted, and policy questions barely register in either file.

### Keyword export

One label (a product, service or location under the brand) holds well over half of the 300 terms I read, so I split it into sub-jobs: a sub-brand by name, a specific hotel by name, a hotel by its street address, a hotel by its airport, and a vacation club or all-inclusive stay. The rows below show the range of jobs, not the ten biggest terms.

| What someone is searching for | Keyword | Estimated monthly searches |
|---|---|---|
| The brand itself | hilton | 1500000 |
| An account or login | hilton honors login | 110000 |
| Use a staff rate or staff system (new label) | go hilton | 60500 |
| A hotel by its street address (sub-job) | hilton 1600 lamar street houston tx 77010 | 27100 |
| A nearby or local version | embassy suites near me | 22200 |
| A hotel by its airport (sub-job) | hilton boston logan airport | 18100 |
| A payment or card product | hilton credit card | 14800 |
| Support | hilton honors phone number | 12100 |
| The brand paired with a need | hilton all inclusive resorts | 8100 |
| Access during use | hilton wifi | 4400 |
| A discount or promo | hilton promo code | 2900 |
| A policy or terms question | hilton cancellation policy | 1000 |

What's there is navigation: people know the hotel and want its page, and a surprising number of them search the street address or the airport rather than the hotel's name. The second thing is Honors as an account to get into (login, card, points, phone number) rather than a program to learn about. What's missing is anything before the decision: reviews and "is it legit" are nearly absent, cancellation sits at 1000 searches against 110000 for the login, and the few terms that put Hilton next to Marriott ("hilton marriott hotel", "hilton by marriott") read as confusion, not comparison. What surprised me is the staff traffic: "go hilton", "hilton go", "hilton lobby" (the team member portal at lobbylite.hilton.com), "hilton team member travel" and "hilton employee discount" together outrank the credit card and customer service, and none of them fit an existing label, so I added one. The other surprise is where some jobs land: "hilton wifi" and "wifi at hilton hotels" rank on the Honors login page, and "hilton remote jobs" ranks on a travel article about working remotely rather than a careers page.

### Prompt export

| What someone is trying to do with the answer they get | Prompt | AI answer engine |
|---|---|---|
| Plan around using it | What are the best restaurants near Hilton Midtown in NYC? | chatgpt, gemini |
| Compare where to buy it | How do I find the best deals for Hilton Garden Inn Visalia on hotel booking sites? | gemini, google_ai_mode |
| Choose within the brand | What are the best Hilton hotels to stay at in Denver, Milwaukee, and Salt Lake City? | chatgpt |
| Compare the brand with competitors | How do reviews of Hilton Bankside compare to other London hotels? | chatgpt, gemini |
| Use or understand a named feature | convert hilton points to airline miles | google_ai_overview |
| Get help during use | What are the steps to log into Marriott or Hilton WiFi networks? | google_ai_mode |
| Check whether it's trustworthy | Where can I find reviews or complaints about the Curio Room or Hilton services? | chatgpt |
| Find a discount | Are there any exclusive Hilton or Marriott discount codes available online? | chatgpt |
| Look up one named product or location | hilton atlanta 255 courtland st ne atlanta ga 30303 | google_ai_overview |
| Evaluate for business or partner use | How do Hilton's loyalty rewards work for travel agents? | chatgpt |

What's there is the stay already booked or nearly booked: by far the most common prompt names a specific Hilton property and asks what to eat or do near it, and the next most common asks which booking site has the best rate for a named hotel, which means the brand has won the choice and is now at risk of losing the sale. Comparison with rivals happens at the property level ("Hilton Bankside" against other London hotels) and in pairs with Marriott or Hyatt, not as "Hilton versus Marriott" as chains. What's missing is any prompt about joining Honors, applying for the card, cancelling, paying or pets; I searched the whole matched set and found none. The engine column changes the shape: google_ai_overview rows are short, keyword-style lookups ("hilton milwaukee city center", "how to use hilton resort credit"), while chatgpt, gemini and google_ai_mode rows are full questions, so the same person types a name into Google and a question into a chatbot.

### Action items

1. "go hilton", "hilton go", "hilton lobby", "hilton team member travel", "hilton employee discount": staff are using the public brand name to reach their own systems and rates. Give the Go Hilton page and the Lobby login a plain, short route that finishes the job in one click, and check that the guest homepage isn't what comes up for "hilton go".

2. "hilton wifi", "wifi at hilton hotels", "hilton wifi login" land on the Honors login page, and in AI engines people ask "What are the steps to log into Marriott or Hilton WiFi networks?": a guest in the room wanting the internet gets a loyalty sign-in. Build one plain wifi help page that answers the on-property job and that an answer engine can quote.

3. "How do I find the best deals for Hilton Garden Inn Visalia on hotel booking sites?" and the many prompts shaped like it (Rockford, Fairbanks, Lehi, Ankara, Zagreb, Skopje): the person has chosen the hotel and is asking a chatbot where to buy it. Put the reason to book direct (the member rate, the price match, whatever the claim is) in plain words on each property page so the answer engine has something to quote when it names the booking sites.

4. "hilton remote jobs", "hilton careers work from home", "work at home jobs hilton" rank on a travel article about working remotely from anywhere: a job seeker lands on a travel blog post. Point these at the careers site, or give the article a visible link to it.

### The question this data can't answer

Whether the street-address and airport searches are new guests choosing or booked guests navigating; a Search Console export of queries by landing page, or the on-site search log, would show whether those visitors book or just look up directions.

A backlink export is the third kind of file this reads and wasn't uploaded; it would show why other sites link to Hilton.
