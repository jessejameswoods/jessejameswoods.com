# brand-signal-reader test run: Insurify

User message: "Insurify is a car insurance comparison site. Keywords, AI prompts and backlinks attached. What are people trying to do with the brand name?"

Files: insurify-keywords.csv, insurify-prompts.csv, insurify-backlinks.csv

---

## Step 1. One question first

Q (skill): What's the brand, and what other names do people use for it (sub-brands, product lines, the domain, misspellings)?

A (user): Insurify. insurify.com. Misspellings: insurfy, insurrify, insureify.

Aliases I'll match on: insurify, insurfy, insurrify, insureify. The domain counts with and without the TLD, so "insurify" already covers insurify.com.

## Step 2. Confirm each file

Q (skill): insurify-keywords.csv is a Semrush organic Positions export. I'll read `Keyword` as the term and `Search Volume` as the volume column. The file repeats a keyword once per `Position Type` (Organic, AI overview, Knowledge panel) and also once per `Timestamp`, so the same keyword shows up many times; I'll collapse those to unique terms before matching and take the largest `Search Volume` where copies disagree. I'll use `URL` only to see which page currently answers a job. Is that right?

A (user): yes

Q (skill): insurify-prompts.csv is a Semrush AI Toolkit prompt export. I'll read `prompt` as the prompt and `llm` as the engine column; the file repeats a prompt once per engine, so I'll keep the engines together per prompt. The columns are `prompt, llm, topic_name, topic_visibility, brief_response`, which means these come from Semrush's database of prompts people asked, so the rows are observed demand, not a list you track. Is that right?

A (user): yes

Q (skill): insurify-backlinks.csv is a Semrush backlinks export, comma-separated. I'll read `Source url` as the linking page (with `Source title` to name the site), `Target url` as the target page, `Anchor` for the link text, and `Page ascore` as the authority column. The file repeats source and target pairs, so I'll collapse to unique pairs and keep the highest `Page ascore` where copies disagree. Is that right?

A (user): yes

## Step 3. Match, check, sample

### Keyword file

Match line: 97 of 112 unique terms contain an alias.

Q (skill): Here are five matched terms from the middle of the matches, not the top:

- insurify inc
- insurify insurance
- insurify insurance agency
- insurify insurance agency reviews
- insurify insurance company

I looked for the three things a name match lets through. Insurify isn't a dictionary word, a place or a person, so nothing matched on another meaning. For an alias hiding inside another word, three terms have the alias run together with other letters, and all three are still the brand:

- insurifycar
- affordable car insuranceinsurify
- cheapest car insuranceinsurify

Five unmatched terms that look like misspellings of an alias:

- insurafy
- insurefy
- isurify
- imsurify
- ensurify insurance

Skip line: the rest of the unmatched terms are misspelling-shaped too, apart from "sureify car insurance", which may be another company (Sureify is a life insurance software firm). Keep, drop or add?

A (user): Keep all the matched ones. Add those five misspellings. If the other unmatched ones are misspellings too, add them as well, but leave sureify out, that's a different company.

Added as aliases after showing them: insurafy, insurefy, isurify, imsurify, ensurify, insuify, insurift, insirify, insurifu, insurfiy, insurafy.com, insurified, ensurify.com, insurfi.com. Left out: sureify car insurance. Exclusion rule applied: none needed, no phrase exclusions. Updated match line: 111 of 112 unique terms contain an alias.

Sampling line: 111 matched terms is under 300, so I read every matched term in full.

### Prompt file

Skip line: two rows equal their `topic_name` ("Insurify Car Insurance Reviews and Legitimacy" and "Insurify and Insurance Industry Insights"); those are topic labels, not something a person typed, so I skipped them.

Match line: 60 of 60 unique prompts contain an alias.

Q (skill): Five matched prompts from the middle of the matches:

- insurify complaints
- insurify reviews
- insurify commercial
- insurify car insurance reviews
- is insurify a legitimate company

The same three checks: no other-meaning matches, no place or person, and no alias hiding inside another word in this file. No unmatched prompts, so nothing to add. Keep, drop or add?

A (user): Keep, nothing to add.

Sampling line: 60 matched prompts, read in full.

### Backlink file

Every `Target url` in the file contains insurify.com, so there's no match line for this file. Skip line: I dropped three rows whose linking page is on the brand's own domains (insurify.ca and insurify.co). Collapsed to 28,997 unique source and target pairs.

Q (skill): Five matched pairs from the middle of the pairs, ordered by `Page ascore`:

- caredge.com "2025 Mitsubishi Outlander Pricing, Deals and Research" links to https://insurify.com/start/auto/partner/caredge/, anchor "Insurance Compare quotes & save hundreds"
- caredge.com "Certified Pre Owned Hyundai Santa Fe" links to https://insurify.com/start/auto/partner/caredge/
- libertymutual.com "New York Car Insurance | Get a Quote | Liberty Mutual" links to https://insurify.com/car-insurance/new-york/average-cost/, anchor "pay more"
- motor.com "Electric Vehicles: Costs, Trends and Statistics 2024 | MOTOR" links to https://insurify.com/car-insurance/maine/, anchor "Maine"
- news.nationwide.com "Nationwide Expands Investment Fund to $350M" links to https://insurify.com/, anchor "Insurify"

The three checks apply to the target match, and every target is insurify.com, so none of them hit. Two things worth flagging before I read: a cluster of blogspot.com pages link to the homepage with anchors like "ensurify" and "https://franksinsurance.com/", and many rows are Yahoo search result pages (fi.search.yahoo.com, uk.search.yahoo.com and so on) that scraped an Insurify listing. Both are in the file and I'll label them rather than drop them. Keep, drop or add?

A (user): Keep. Label the spam as what it is; I want to see it.

Sampling line: Reading the top 300 unique pairs by Page ascore. Before saying any job was missing, I searched the whole set of pairs for partner targets, reviews, app stores, careers, the Spanish site, promo codes, forums and login pages.

## Step 4 and 5. Labels and output

I read `references/categories.md` and `references/moves.md` before labeling. In the backlink sample, "Research or data the brand published" held well over half the rows, so I split it into three sub-jobs and say so in the reading. In the prompt file, "Check whether it's trustworthy" held about half, right at the line, so I split it too. In the keyword file no label passed half. I added one keyword label, one prompt label and two link labels; each is marked new.

---

# What's landing

The strongest job in the data is someone who has already heard the name and wants to know whether Insurify is real before they hand over their details: legit, scam, safe, reviews, and on the link side the same question answered by Consumer Reports, Bankrate and The Zebra. The job that's thin is anything after the quote: there's no policy question, no discount row, no app row, and the support searches land on a contact page that a comparison site can't finish for a customer whose insurer is someone else.

## Keywords

| What someone is searching for | Keyword | Estimated monthly searches |
|---|---|---|
| The brand itself | insurfy | 390 |
| Work out what the brand actually is (new) | is insurify an insurance company | 30 |
| A product, service or location under the brand | insurify home insurance | 1000 |
| The brand paired with a need | insurify auto insurance quote | 5400 |
| Reviews or whether to trust it | is insurify legitimate | 1000 |
| Support | insurify phone number | 1300 |
| An account or login | insurify login | 210 |
| The company behind the brand | insurify careers | 320 |
| A named feature or tool | insurify car insurance calculator | 40 |
| The right country or language edition | insurify en español | 70 |

The biggest rows are people asking Insurify to do the one thing it does, get a car insurance quote, and those land on https://insurify.com/car-insurance/ or the homepage. Under that sit the other product lines (home, renters, pet, life, motorcycle, and "insurify seven insurance", which lands on https://insurify.com/insurify-car/), then a thick trust strand that runs from "insurify car insurance reviews" to "is insurify real". What surprised me is the label I had to add: "what is insurify insurance", "is insurify an insurance company" and "insurify insurance agency" are people who can't tell whether Insurify sells insurance or compares it, and every one of those lands on the homepage or the contact page rather than a page that says so. The support rows are large for a marketplace ("insurify phone number", "insurify customer service number", "insurify phone number near me") and the "near me" variants suggest people think there's a local office. What's missing is anything after purchase: no cancellation, no claim, no policy, no app, and the only feature searched by name is the calculator, plus "insurify chatgpt" and "insurify ai" at the bottom.

## Prompts

| What someone is trying to do with the answer they get | Prompt | AI answer engine |
|---|---|---|
| Check whether it's trustworthy: scam or legit | is insurify a scam | google_ai_overview |
| Check whether it's trustworthy: what reviews say, and where | insurify reviews bbb | google_ai_overview |
| Check whether it's trustworthy: whether it actually works | does insurify work | google_ai_overview |
| Check whether it's trustworthy | Is Insurify a trustworthy platform for purchasing auto insurance? | chatgpt, gemini, google_ai_mode |
| Compare the brand with competitors | How does Insurify compare with other insurance comparison platforms? | chatgpt, gemini, google_ai_mode |
| Decide whether to sign up, apply or buy | What are the main features and benefits of Insurify car insurance? | chatgpt, gemini, google_ai_mode |
| Learn how to do something in it | How can I get a quote from Insurify and what coverage options do they offer? | chatgpt, gemini, google_ai_mode |
| Learn about the company behind the brand | how does insurify make money | google_ai_overview |
| Work out what the brand actually is (new) | insurify meaning | google_ai_overview |
| Get help during use | insurify login | google_ai_overview |

These are observed prompts, so this is what people asked, not a tracked list. Trust is the center of the file and it comes in three shapes: a yes-or-no on scam or legit, a check of what a named place says (Reddit, BBB, Consumer Reports), and a plainer "is insurify good" or "does insurify work". The full-sentence prompts on chatgpt, gemini and google_ai_mode are a small set and they skew to the company (history, key people, industry trends, how it compares), while google_ai_overview carries the keyword-shaped rows, which read like the Google search box with an AI answer on top. The same confusion from the keyword file shows up here as "what is insurify", "insurify meaning" and "how does insurify make money". Nothing asks about a specific carrier through Insurify, a state, a price, or home insurance beyond one bare "insurify home insurance", so the AI side hasn't reached the shopping stage at all.

## Backlinks

| What stood out | Evidence | Why it matters |
|---|---|---|
| Research the brand published: the home insurance price report | npr.org "California home insurance is at the mercy of climate change : NPR", cnbc.com "Florida, California insurance crisis is spreading. Is your state next?" and usatoday.com "Homeowners insurance costs surge. What owners and buyers need to know." all link to https://insurify.com/homeowners-insurance/report/home-insurance-price-projections/; bbc.com "'Who will buy my house if they can't get insurance'" links to the 2023 edition at https://insurify.com/report/homeowners-insurance/2023-price-projections/ | One URL carries most of the national news coverage in the file; it's the brand's best asset and it has to stay put |
| Research the brand published: the car insurance rate report | foxbusiness.com "Car insurance rates rising in over 32 states this year, report finds | Fox Business" links to https://insurify.com/car-insurance/report/, anchor "analysis by Insurify"; nytimes.com "Auto Insurance Spike Hampers the Inflation Fight - The New York Times" links to the same page | The car report gets the same treatment as the home one, so the method is repeatable |
| Research the brand published: driver and car-model studies | jalopnik.com "These Are The 10 Most Popular Cars Millennials Drive" links to https://insurify.com/car-insurance/insights/most-popular-cars-by-generation/, anchor "study by Insurify"; aol.com "These 10 states are getting hit the hardest by severe hailstorms - AOL" links to https://insurify.com/car-insurance/insights/states-with-highest-increase-in-hail/ | Lifestyle and auto sites pick up the lighter studies, which reach people who aren't shopping |
| A partnership page | caredge.com "2025 Mitsubishi Outlander Pricing, Deals and Research" links to https://insurify.com/start/auto/partner/caredge/, anchor "Insurance Compare quotes & save hundreds"; alumni.berkeley.edu "Home - Cal Alumni Association" links to https://insurify.com/start/auto/partner/ucberkeley/; deltasigmapi.org "Delta Sigma Pi - Professional Business Fraternity" links to https://insurify.com/start/auto/partner/dsp/ | Sitewide partner placements make up most of the unique pairs in the file, and the top-by-authority sample barely shows them |
| Recognition the linked site displays | visitpittsburgh.com "Pittsburgh Accolades & Rankings | Visit Pittsburgh Press Kit | Visit Pittsburgh" links to http://insurify.com/insights/best-cities-for-singles-awards-2021/; oshkoshchamber.com "National Rankings & Honors - Oshkosh Chamber" links to https://insurify.com/insights/greenest-city-awards/ | Cities keep Insurify's awards on their press pages for years; a durable link source that costs nothing more than publishing a ranking |
| A tool with a name | bankrate.com "Insurify Insurance Review | Bankrate" links to https://insurify.com/car-insurance/calculator/, anchor "car insurance calculator"; cnbc.com "Jerry Car Insurance Comparison Shopping Tool Review 2026" links to https://insurify.com/, anchor "Insurify's ChatGPT app" | The calculator and the ChatGPT app are the two things reviewers point at by name |
| A ranking or award that names the brand | cnbc.com "Best AI-Powered Insurance Shopping Tools" links to https://insurify.com/; women-presidents.com "WPO | 2022 50 Fastest List" links to https://insurify.com/ | The AI angle is how CNBC files Insurify now, not as a quote site |
| A review or warning about the brand (new) | consumerreports.org "Auto Insurance Quote Comparison Websites Privacy Issues - Consumer Reports" links to https://insurify.com/, anchor "Insurify"; thezebra.com "Insurify: A Review | The Zebra" links to https://insurify.com/homeowners-insurance/ | The highest-authority link in the whole file is a privacy warning, and it answers the trust prompts for people |
| Coverage of company news (new) | techcrunch.com "Insurify, a 'virtual insurance agent,' raises $100M Series B | TechCrunch" links to https://insurify.com/; nationwide.com "Nationwide Ventures®" links to http://www.insurify.com/ | Funding and investor pages explain "how does insurify make money" better than the site does |
| Spam that borrows the name (new) | easuyet.blogspot.com "easuyet" links to https://insurify.com/, anchor "ensurify"; xjlzzscxd.blogspot.com "xjlzzsbn" links to https://insurify.com/, anchor "https://franksinsurance.com/" | A cluster of throwaway blogs points at the homepage with misspelled or unrelated anchors |

Insurify is cited far more than it's recommended: the news links are to its numbers, not to its quote form, and even insurers borrow them (libertymutual.com "New York Car Insurance | Get a Quote | Liberty Mutual" links to https://insurify.com/car-insurance/new-york/average-cost/ with the anchor "pay more"). The research label held well over half of the top 300, which is why it's split three ways above. Reading by authority hides the shape of the rest of the file: caredge.com alone, with one sitewide partner link on every car page, accounts for most of the unique pairs, and the Cal Alumni Association does the same at smaller scale, so the "link profile" is really two things, a press clipping file and a handful of partner placements. What's missing is the affiliate layer you'd expect for a comparison site: the only row that looks like one is realtor.com linking to https://insurify.com/save/quote-offers-s4-2/ with a utm_partner tag, and there's nothing to the login page, the app, or the Spanish site beyond Yahoo search scrapes. The surprise is at the top: the single strongest link is Consumer Reports warning about privacy on quote comparison sites, which is the page a person checking "is insurify safe" is most likely to find.

## Action items

1. From "what is insurify insurance", "is insurify an insurance company", "insurify insurance agency" and the prompts "what is insurify", "insurify meaning" and "how does insurify make money": people can't tell whether Insurify sells insurance or compares it, and those rows all land on https://insurify.com/ or https://insurify.com/company/contact/. Put the answer in the first sentence of the homepage and on one plain page that says what Insurify is, who the carriers are and how it gets paid, written so google_ai_overview can quote it.

2. From "insurify phone number" (1300), "insurify customer service number", "insurify phone number near me" and "insurify insurance phone number near me", which land on https://insurify.com/company/contact/ and https://insurify.com/company/client-support/: someone calling a comparison site after buying usually wants the carrier. Make the contact page route by carrier first and measure whether the calls and the "near me" searches fall.

3. From the home report URL cited by npr.org, cnbc.com, usatoday.com and realtor.com, and the car report cited by foxbusiness.com and nytimes.com: the reports are the link engine. Keep each at one dated URL with a method section, and aim the next one at the privacy question Consumer Reports raised, because the trust prompts (is insurify safe, insurify reviews consumer reports) are being answered by other people's pages.

4. From caredge.com, alumni.berkeley.edu, deltasigmapi.org, chaiz.com and viva-finance.com all linking to pages under https://insurify.com/start/auto/partner/: partner placements are most of the file's unique links and none of its coverage. Before adding another, work out which of the existing ones produce quotes and set the rule for what a partner page has to show.

## The question this data can't answer

Whether the people asking "is insurify legit" go on to get a quote or stop there; Search Console landing-page data joined to quote starts for those terms, plus the reasons logged on the contact line, would show it.
