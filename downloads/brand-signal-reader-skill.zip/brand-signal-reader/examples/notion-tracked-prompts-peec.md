# Brand signal reader test run: Notion Peec export

User message: "Here's our Peec export for Notion. What does it say about what people want from the brand?"

Input: /home/claude/bsr-tests/peec_prompts_notion_export.csv

---

## Conversation

Q (skill):
What's the brand, and what other names do people use for it (sub-brands, product lines, the domain, misspellings)?

A (user):
Notion. Notion AI, Notion Calendar, Notion Mail, notion.so.

Q (skill):
Thanks. One file, and I read it as a Peec prompt export. Here's how I'll read it; tell me yes or correct me.

- Prompt column: `prompt`
- Engine column: `models` (values like `chatgpt;gemini;perplexity`, so I'll list them per prompt)
- Visibility and position columns are present: `visibility` and `position`. There's also a `volume` column, but it holds `high`, `medium`, `low` rather than numbers, and the prompt table doesn't carry a volume column anyway, so I won't show it.
- I'll ignore `topic`, `tags`, `country` and `sentiment` for the table, though I may mention what `sentiment` says in the reading.

Aliases I'll match on: notion, notion ai, notion calendar, notion mail, notion.so (and "notion" on its own covers the domain without the TLD).

On where the prompts came from: Peec tracks prompts you uploaded, wrote or accepted from its suggestions, and this file has visibility and position columns with nothing saying the prompts were observed. These are prompts you track, so this reads your own question list back to you. If that's wrong and these were pulled from a database of real asked prompts, say so now and the reading changes.

Is that right?

A (user):
Yes. We wrote most of them and accepted some of Peec's suggestions.

Q (skill):
Good, that confirms it. I ran the match. No duplicate prompts to collapse; each prompt appears once with its engines already joined in the `models` column.

37 of 38 unique prompts contain an alias.

The one that doesn't: "What is the best note-taking app for a small startup team?" I'll skip it since it doesn't name the brand, but I'll mention it in the reading because it's the only prompt in the list written by someone who doesn't know Notion yet.

Five matched prompts from the middle of the matches, not the top:

- Why is my Notion page loading slowly?
- How do I recover a deleted page in Notion?
- How do I export my Notion workspace to Markdown?
- Can Notion integrate with Slack and Google Calendar?
- Does Notion have an API I can use to sync tasks from Linear?

Are these about the brand? "Notion" is also an ordinary word, so a prompt like "the notion of productivity" would slip through, but none of these five read that way. If you agree, I'll read all 37 with no exclusions.

A (user):
Yes, all five are about Notion. I looked through the rest too and none of them use "notion" as a regular word. No exclusions needed.

---

## Reading

The strongest job in this list is comparing Notion with a named rival for a specific team or use case: Confluence for a 50-person engineering team, Obsidian for personal knowledge, Jira for a product team, Google Docs for a solo consultant, ChatGPT for meeting notes. The thin job is the plain decision to buy: only one prompt asks whether a paid plan is worth it, so the list jumps from "which tool" straight to "how do I" with almost nothing in between.

These are prompts you track, so this reads your own question list back to you. You said you wrote most of them and accepted some of Peec's suggestions, so what follows is a reading of what your team thinks people ask, checked against what the rows actually say.

Skipped one prompt that contains no alias: "What is the best note-taking app for a small startup team?"

| What someone is trying to do with the answer they get | Prompt | models |
|---|---|---|
| Compare the brand with competitors | Is Notion or Confluence better for a 50-person engineering team? | chatgpt;gemini;perplexity |
| Compare the brand with competitors | What are the best Notion alternatives in 2026? | chatgpt;gemini;perplexity |
| Check whether it's trustworthy | Is Notion SOC 2 and GDPR compliant? | chatgpt;perplexity |
| Check whether it can do a specific thing (new label) | Does Notion work offline? | chatgpt;gemini;perplexity |
| Learn how to do a task in it (new label) | How do I set up a CRM in Notion? | chatgpt;gemini |
| Choose within the brand | What's the best Notion template for a weekly planner? | chatgpt;gemini;perplexity |
| Get help during use | How do I recover a deleted page in Notion? | chatgpt;gemini;perplexity |
| Use or understand a named feature | How does Notion Mail work? | chatgpt;gemini;perplexity |
| Find a discount | Is there a Notion student discount or education plan? | chatgpt;gemini;perplexity |
| Evaluate for business or partner use | How do I become a Notion certified consultant? | chatgpt;perplexity |

Three labels in that table are new. "Check whether it can do a specific thing" holds the capability checks that aren't about a feature anyone remembers by name: offline, Slack and Google Calendar, an API for Linear, two people editing at once, offline editing on mobile. "Learn how to do a task in it" holds the how-to rows: a content calendar in databases, a CRM, sharing a page outside the workspace, exporting to Markdown, migrating from Evernote. "Work out what it costs" holds "How much does Notion cost for a team of 20?" and "Is Notion AI included in the Business plan?", which are price questions rather than buy-or-don't questions. Neither of the first two fit "Use or understand a named feature", which is for things like Notion AI, Notion Calendar and Notion Mail, and those three sub-brands each got exactly one prompt here. No label holds more than half the rows, so nothing needed splitting.

What's there is a list written by people who know the product well. Every rival in the compare rows comes with a team size or a job attached, the trust rows ask about SOC 2 and GDPR by name, and the partner rows know there's a certification and an affiliate program to ask about. What's missing is the person who hasn't heard of Notion yet. The only prompt in that voice is the one I skipped, and a tracked list can't tell you how many more of those exist. There's also no prompt about Notion's pricing against a rival's and no prompt about what happens to your data if you leave. Someone who already pays and wants more out of the product shows up in just three support rows.

What surprised me is how the leaving path is already in the list: "What are the best Notion alternatives in 2026?", "How do I export my Notion workspace to Markdown?" and "How do I cancel my Notion subscription?" sit alongside the arrival path ("How do I migrate from Evernote to Notion?"). The two offline rows are the other surprise. "Does Notion work offline?" and "Does the Notion mobile app support offline editing?" are the only rows besides the alternatives prompt and the slow-page prompt where the `sentiment` column reads negative, and offline is the one capability question in the file that your own page can't answer with a yes.

Action items:

1. The compare rows name Confluence, Obsidian, Jira, ChatGPT, Google Docs and Roam, each tied to a team size or a use case. Make one plain comparison page per rival, written for that team size, with current claims an answer engine can quote. Right now the answer is choosing between you and a rival you didn't pick.

2. "Does Notion work offline?" and "Does the Notion mobile app support offline editing?" both carry negative sentiment in the file. Write one honest offline page that says exactly what works without a connection, on desktop and on mobile, so the answer engines quote you instead of a forum thread.

3. "How do I become a Notion certified consultant?", "Does Notion have an affiliate program?" and "Can I run my whole company wiki on Notion for 500 employees?" are three different audiences (consultant, affiliate, enterprise buyer) that the list already attracts. Check each has a page that finishes the job and that the page is written for that person rather than the average visitor.

4. 37 of 38 prompts contain the brand name. Add a set of prompts written the way the skipped row is written, by someone describing the problem without knowing your name, so the next export shows whether Notion gets recommended when nobody asks for it.

The question this data can't answer: whether anyone outside your team asks these questions in these words. An observed-demand export (Semrush AI Toolkit's prompt database, or a branded keyword export from Search Console) would show which of these jobs real people bring to the name, and which ones you wrote because you hoped they did.

You uploaded one file. A keyword reading and a backlink reading are available if you send those exports too.
